<?php
require __DIR__ . '/config.php';

function finish(string $title, string $message): never {
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title><body style="font:16px Arial;max-width:800px;margin:40px auto">';
    echo '<h1>' . htmlspecialchars($title) . '</h1><p>' . htmlspecialchars($message) . '</p><p><a href="index.php">Store</a> | <a href="cart.php">Cart</a> | <a href="orders.php">Orders</a></p></body></html>';
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: cart.php'); exit; }

$customer = trim((string)($_POST['customer_name'] ?? ''));
$method = (string)($_POST['payment_method'] ?? 'CARD');
if ($customer === '') finish('Missing information', 'Enter a customer name.');
if (!in_array($method, ['CARD','EWALLET','BANK'], true)) $method = 'CARD';

$cart = $_SESSION['cart'] ?? [];
if (!$cart) finish('Empty cart', 'Add an item before checkout.');

$pdo = cart_db();
$ids = array_map('intval', array_keys($cart));
$marks = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT id,name,price,stock FROM products WHERE id IN ($marks)");
$stmt->execute($ids);
$products = $stmt->fetchAll();
$total = 0.0; $validItems = [];
foreach ($products as $p) {
    $qty = min((int)$cart[$p['id']], (int)$p['stock']);
    if ($qty > 0) {
        $total += $qty * (float)$p['price'];
        $validItems[] = ['product'=>$p,'qty'=>$qty];
    }
}
if (!$validItems || $total <= 0) finish('Checkout error', 'No valid items were found.');

/* Persist order before calling the independent payment service. */
$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("INSERT INTO orders (customer_name,total_amount,status) VALUES (?,?,'PENDING_PAYMENT')");
    $stmt->execute([$customer, number_format($total,2,'.','')]);
    $orderId = (int)$pdo->lastInsertId();
    $itemStmt = $pdo->prepare('INSERT INTO order_items (order_id,product_id,product_name,quantity,unit_price) VALUES (?,?,?,?,?)');
    foreach ($validItems as $i) {
        $itemStmt->execute([$orderId,$i['product']['id'],$i['product']['name'],$i['qty'],$i['product']['price']]);
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    finish('Order error', 'Could not save the order.');
}



/*
 * STUDENT TASK: Integrate the shopping cart with the
 * independent payment gateway.
 *
 * Requirements:
 * 1. Prepare the payment request payload.
 * 2. Send an HTTP POST request with JSON using PHP cURL.
 * 3. Handle the gateway's HTTP response.
 * 4. Validate the response and match the order ID.
 * 5. Handle SUCCESS, FAILED, and PENDING outcomes.
 * 6. Handle timeouts and invalid responses safely.
 * 7. Save the gateway transaction ID and update the
 *    order status in the shopping cart database.
 * 8. Prevent duplicate payment requests using an
 *    idempotency key.
 *
 * Read payment-gateway/README-API.md for the API contract.
 */

// TODO: Implement the system integration here.
$apiUrl = "http://localhost/payment-gateway/api/payments.php";
$idempotencyKey = "cart-order-" . $orderId;

$paymentStatus = "PAYMENT_PENDING";
$transactionId = null;
$message = "Payment status could not be confirmed. Verify before retrying.";

$payload = [
    "order_id" => (int) $orderId,
    "amount" => round((float) $total, 2),
    "customer_name" => $customer,
    "payment_method" => $method,
    "idempotency_key" => $idempotencyKey,
    "outcome" => "PENDING"
];

$jsonPayload = json_encode($payload);

if ($jsonPayload === false) {
    $message = "Could not prepare payment request.";

} elseif (!function_exists("curl_init")) {
    $message = "cURL is not enabled.";

} else {
    $ch = curl_init($apiUrl);

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $jsonPayload,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Accept: application/json"
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_errno($ch);

    curl_close($ch);

    if ($response === false || $curlError !== 0) {
        $message = "Connection error or timeout. Verify payment before retrying.";

    } elseif ($httpCode < 200 || $httpCode >= 300) {
        switch ($httpCode) {
            case 400:
                $message = "HTTP 400: Invalid JSON request.";
                break;
            case 405:
                $message = "HTTP 405: Incorrect HTTP method.";
                break;
            case 422:
                $message = "HTTP 422: Invalid request fields.";
                break;
            case 500:
                $message = "HTTP 500: Gateway server or database error.";
                break;
            default:
                $message = "Gateway HTTP error. Verify payment before retrying.";
        }

    } else {
        $result = json_decode($response, true);

        $validResponse =
            is_array($result) &&
            json_last_error() === JSON_ERROR_NONE &&
            ($result["success"] ?? false) === true &&
            isset(
                $result["transaction_id"],
                $result["order_id"],
                $result["amount"],
                $result["status"],
                $result["message"]
            ) &&
            is_string($result["transaction_id"]) &&
            $result["transaction_id"] !== "" &&
            (string) $result["order_id"] === (string) $orderId &&
            is_numeric($result["amount"]) &&
            abs((float) $result["amount"] - (float) $total) < 0.005 &&
            in_array(
                strtoupper((string) $result["status"]),
                ["SUCCESS", "FAILED", "PENDING"],
                true
            );

        if (!$validResponse) {
            $message = "Invalid gateway response. Verify payment before retrying.";

        } else {
            $transactionId = $result["transaction_id"];
            $message = (string) $result["message"];

            switch (strtoupper((string) $result["status"])) {
                case "SUCCESS":
                    $paymentStatus = "PAID";
                    break;

                case "FAILED":
                    $paymentStatus = "PAYMENT_FAILED";
                    break;

                case "PENDING":
                    $paymentStatus = "PAYMENT_PENDING";
                    break;
            }
        }
    }
}

try {
    $stmt = $pdo->prepare(
        "UPDATE orders
         SET status = ?,
             gateway_transaction_id =
                 COALESCE(?, gateway_transaction_id)
         WHERE id = ?"
    );

    $stmt->execute([
        $paymentStatus,
        $transactionId,
        $orderId
    ]);

    $check = $pdo->prepare(
        "SELECT id FROM orders WHERE id = ?"
    );
    $check->execute([$orderId]);

    if (!$check->fetchColumn()) {
        finish("Database Error", "The order could not be found.");
    }

} catch (PDOException $e) {
    finish(
        "Database Warning",
        "Could not save the payment result. Verify the transaction before retrying."
    );
}

// TODO: Display the appropriate checkout result.
echo "<h2>Checkout Result</h2>";

echo "<p>" .
    htmlspecialchars($message, ENT_QUOTES, "UTF-8") .
    "</p>";

echo "<p>Order ID: " .
    htmlspecialchars((string) $orderId, ENT_QUOTES, "UTF-8") .
    "</p>";

echo "<p>Amount: " .
    htmlspecialchars((string) $total, ENT_QUOTES, "UTF-8") .
    "</p>";

echo "<p>Payment Status: " .
    htmlspecialchars($paymentStatus, ENT_QUOTES, "UTF-8") .
    "</p>";

if ($transactionId !== null) {
    echo "<p>Transaction ID: " .
        htmlspecialchars($transactionId, ENT_QUOTES, "UTF-8") .
        "</p>";
}

if ($paymentStatus === "PAID") {
    echo "<p>Payment successful!</p>";
} elseif ($paymentStatus === "PAYMENT_FAILED") {
    echo "<p>Payment failed. Please check your order.</p>";
} else {
    echo "<p>Payment is pending or could not be confirmed. Verify the order before retrying.</p>";
}

